package controller;

import model.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentController {
    private Connection conn;

    public StudentController() {
        try {
            // SQLite database; ByteXL handles it automatically
            conn = DriverManager.getConnection("jdbc:sqlite:students.db");
            Statement st = conn.createStatement();
            st.execute("CREATE TABLE IF NOT EXISTS students (student_id INTEGER PRIMARY KEY, name TEXT, department TEXT, marks INTEGER)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean addStudent(Student s) {
        try {
            PreparedStatement pst = conn.prepareStatement("INSERT INTO students VALUES (?, ?, ?, ?)");
            pst.setInt(1, s.getStudentId());
            pst.setString(2, s.getName());
            pst.setString(3, s.getDepartment());
            pst.setInt(4, s.getMarks());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        try {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM students");
            while (rs.next()) {
                list.add(new Student(rs.getInt("student_id"), rs.getString("name"),
                                     rs.getString("department"), rs.getInt("marks")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean updateStudent(Student s) {
        try {
            PreparedStatement pst = conn.prepareStatement("UPDATE students SET name=?, department=?, marks=? WHERE student_id=?");
            pst.setString(1, s.getName());
            pst.setString(2, s.getDepartment());
            pst.setInt(3, s.getMarks());
            pst.setInt(4, s.getStudentId());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean deleteStudent(int id) {
        try {
            PreparedStatement pst = conn.prepareStatement("DELETE FROM students WHERE student_id=?");
            pst.setInt(1, id);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }
}
