package view;

import controller.StudentController;
import model.Student;
import java.util.List;
import java.util.Scanner;

public class StudentView {
    private StudentController controller = new StudentController();
    private Scanner sc = new Scanner(System.in);

    public void menu() {
        int choice;
        do {
            System.out.println("\n1. Add Student\n2. View Students\n3. Update Student\n4. Delete Student\n5. Exit");
            System.out.print("Choice: ");
            choice = sc.nextInt(); sc.nextLine();
            switch(choice) {
                case 1 -> addStudent();
                case 2 -> viewStudents();
                case 3 -> updateStudent();
                case 4 -> deleteStudent();
                case 5 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice");
            }
        } while(choice != 5);
    }

    private void addStudent() {
        System.out.print("ID: "); int id = sc.nextInt(); sc.nextLine();
        System.out.print("Name: "); String name = sc.nextLine();
        System.out.print("Department: "); String dept = sc.nextLine();
        System.out.print("Marks: "); int marks = sc.nextInt();
        if(controller.addStudent(new Student(id, name, dept, marks))) System.out.println("Added!");
        else System.out.println("Failed");
    }

    private void viewStudents() {
        List<Student> list = controller.getAllStudents();
        System.out.println("ID\tName\tDepartment\tMarks");
        for(Student s : list) System.out.println(s);
    }

    private void updateStudent() {
        System.out.print("ID to update: "); int id = sc.nextInt(); sc.nextLine();
        System.out.print("New Name: "); String name = sc.nextLine();
        System.out.print("New Dept: "); String dept = sc.nextLine();
        System.out.print("New Marks: "); int marks = sc.nextInt();
        if(controller.updateStudent(new Student(id, name, dept, marks))) System.out.println("Updated!");
        else System.out.println("Failed");
    }

    private void deleteStudent() {
        System.out.print("ID to delete: "); int id = sc.nextInt();
        if(controller.deleteStudent(id)) System.out.println("Deleted!");
        else System.out.println("Failed");
    }
}
