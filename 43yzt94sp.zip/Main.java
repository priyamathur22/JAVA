import view.StudentView;

public class Main {
    public static void main(String[] args) {
        new StudentView().menu();
    }
}
